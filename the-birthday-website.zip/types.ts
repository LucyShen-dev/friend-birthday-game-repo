
export enum GameType {
  LOBBY = 'LOBBY',
  RUSH = 'RUSH',
  BALLOON = 'BALLOON',
  MEMORY = 'MEMORY',
  AI_WISH = 'AI_WISH'
}

export interface GameProps {
  onExit: () => void;
}
