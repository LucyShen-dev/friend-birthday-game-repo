
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateBirthdayWish = async (name: string, vibes: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a short, poetic, and highly aesthetic birthday wish for ${name}. Their favorite vibes are: ${vibes}. Keep it under 60 words. Use emojis like ✨, 🌸, 🕯️, ☁️ where appropriate.`,
      config: {
        temperature: 0.9,
        topP: 0.95,
        maxOutputTokens: 200,
      },
    });

    return response.text || "May your day be as beautiful as a sunset dream. ✨";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The stars are aligned for a beautiful year ahead. Happy Birthday! 🌸";
  }
};
