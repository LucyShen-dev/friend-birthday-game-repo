
import React, { useState, useEffect, useRef } from 'react';
import { GameType } from './types';
import Lobby from './components/Lobby';
import BirthdayRush from './components/BirthdayRush';
import BalloonPop from './components/BalloonPop';
import MemoryLane from './components/MemoryLane';
import AIWishGenerator from './components/AIWishGenerator';

const App: React.FC = () => {
  const [currentGame, setCurrentGame] = useState<GameType>(GameType.LOBBY);
  const [isEntered, setIsEntered] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // A very reliable, public domain Lo-Fi track for background vibes
  const musicUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-17.mp3"; 

  const enterWebsite = () => {
    setIsEntered(true);
    if (audioRef.current) {
      audioRef.current.volume = 0.4;
      audioRef.current.play()
        .then(() => setIsPlaying(true))
        .catch(e => {
          console.log("Audio playback failed. Interaction required.", e);
          // Still set isEntered to true so the user can see the content
          setIsEntered(true);
        });
    }
  };

  const toggleMusic = () => {
    if (audioRef.current) {
      if (audioRef.current.paused) {
        audioRef.current.play().then(() => setIsPlaying(true));
      } else {
        audioRef.current.pause();
        setIsPlaying(false);
      }
    }
  };

  return (
    <div className="relative w-screen h-screen bg-[#66545e] overflow-hidden select-none flex flex-col">
      <audio ref={audioRef} src={musicUrl} loop preLoad="auto" />

      {/* Enter Website Splash Screen */}
      {!isEntered && (
        <div className="fixed inset-0 z-[1000] flex flex-col items-center justify-center bg-[#66545e] text-center px-6">
          <div className="animate-float mb-8">
            <span className="text-9xl drop-shadow-2xl">🎁</span>
          </div>
          <h1 className="text-4xl md:text-7xl font-bold text-[#f6e0b5] mb-6 drop-shadow-xl tracking-tight">
            A Birthday Invitation
          </h1>
          <p className="text-[#eea990] text-lg md:text-2xl mb-12 max-w-2xl font-light italic leading-relaxed">
            "We've curated a small digital corner just for you. Please enter to begin the celebration."
          </p>
          <button 
            onClick={enterWebsite}
            className="group relative px-12 py-5 bg-[#aa6f73] text-[#f6e0b5] rounded-full text-2xl font-bold shadow-2xl hover:bg-[#8b5a5e] hover:scale-105 active:scale-95 transition-all border-2 border-[#f6e0b5]/30 overflow-hidden"
          >
            <span className="relative z-10">ENTER WEBSITE ✨</span>
            <div className="absolute inset-0 bg-white/10 scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></div>
          </button>
        </div>
      )}

      {/* Main Website Content */}
      <main className={`flex-1 relative transition-all duration-1000 transform ${isEntered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        {currentGame === GameType.LOBBY && (
          <Lobby 
            onSelectGame={(game) => setCurrentGame(game)} 
            onToggleMusic={toggleMusic}
            isPlaying={isPlaying}
          />
        )}
        {currentGame === GameType.RUSH && (
          <BirthdayRush onExit={() => setCurrentGame(GameType.LOBBY)} />
        )}
        {currentGame === GameType.BALLOON && (
          <BalloonPop onExit={() => setCurrentGame(GameType.LOBBY)} />
        )}
        {currentGame === GameType.MEMORY && (
          <MemoryLane onExit={() => setCurrentGame(GameType.LOBBY)} />
        )}
        {currentGame === GameType.AI_WISH && (
          <AIWishGenerator onExit={() => setCurrentGame(GameType.LOBBY)} />
        )}
      </main>

      {/* Global Website Status Bar */}
      {isEntered && (
        <footer className="h-14 bg-black/30 backdrop-blur-md border-t border-white/10 flex items-center justify-between px-6 z-[100]">
          <div className="flex items-center gap-4">
            <div className={`flex gap-1 items-end h-5 ${isPlaying ? 'opacity-100' : 'opacity-20'}`}>
              {[1, 2, 3, 4, 5].map(i => (
                <div key={i} className={`w-1 bg-[#eea990] rounded-full ${isPlaying ? 'animate-pulse' : ''}`} style={{ height: `${Math.random() * 80 + 20}%`, animationDelay: `${i * 0.15}s` }}></div>
              ))}
            </div>
            <span className="text-[#f6e0b5] text-[10px] font-black tracking-[0.2em] uppercase opacity-70">
              {isPlaying ? "Vibes Playing" : "Vibes Silent"}
            </span>
          </div>
          
          <div className="hidden sm:block">
            <p className="text-[#f6e0b5] text-[10px] font-black tracking-[0.3em] uppercase opacity-30">
              A Private Celebration &bull; 2025
            </p>
          </div>

          <button 
            onClick={toggleMusic} 
            className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-lg hover:bg-white/20 transition-all text-[#f6e0b5]"
            title={isPlaying ? "Pause Music" : "Play Music"}
          >
            {isPlaying ? '⏸' : '▶'}
          </button>
        </footer>
      )}

      {/* Background Ambience - Slightly reduced opacity for better content contrast */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-[0.07]">
        <div className="absolute top-[10%] left-[5%] text-7xl animate-float">🌸</div>
        <div className="absolute bottom-[15%] right-[10%] text-7xl animate-float" style={{ animationDelay: '1.2s' }}>☁️</div>
        <div className="absolute top-[50%] right-[3%] text-7xl animate-float" style={{ animationDelay: '2.5s' }}>✨</div>
        <div className="absolute top-[70%] left-[8%] text-7xl animate-float" style={{ animationDelay: '3.8s' }}>🩰</div>
      </div>
    </div>
  );
};

export default App;
