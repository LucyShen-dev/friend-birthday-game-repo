
import React, { useEffect, useRef, useState } from 'react';
import { GameProps } from '../types';

const AVATARS = ["🎀", "🩰", "🦢", "🌸", "🧸", "🐚", "🍰"];
const GOODS = ["🎂", "🧁", "🍓", "🍬", "🥨", "🍮"];
const BADS = ["🥦", "💣", "📄", "⏰"];

const BirthdayRush: React.FC<GameProps> = ({ onExit }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'START' | 'PLAYING' | 'OVER'>('START');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0]);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  
  const stateRef = useRef({
    score: 0,
    lives: 3,
    items: [] as any[],
    playerX: 0,
    lastHit: 0,
    keys: {} as Record<string, boolean>
  });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => (stateRef.current.keys[e.code] = true);
    const handleKeyUp = (e: KeyboardEvent) => (stateRef.current.keys[e.code] = false);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useEffect(() => {
    if (gameState !== 'PLAYING') return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    stateRef.current.playerX = canvas.width / 2;

    let frameId: number;

    const spawn = () => {
      const isGood = Math.random() > 0.3;
      stateRef.current.items.push({
        x: Math.random() * (canvas.width - 60) + 30,
        y: -50,
        speed: Math.random() * 3 + 3 + (stateRef.current.score / 200),
        emoji: isGood ? GOODS[Math.floor(Math.random() * GOODS.length)] : BADS[Math.floor(Math.random() * BADS.length)],
        type: isGood ? 'good' : 'bad'
      });
    };

    const update = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Input
      if (stateRef.current.keys['ArrowLeft']) stateRef.current.playerX -= 10;
      if (stateRef.current.keys['ArrowRight']) stateRef.current.playerX += 10;
      
      // Keep in bounds
      if (stateRef.current.playerX < 40) stateRef.current.playerX = 40;
      if (stateRef.current.playerX > canvas.width - 40) stateRef.current.playerX = canvas.width - 40;

      // Draw Player
      const isInvincible = Date.now() - stateRef.current.lastHit < 1000;
      if (!isInvincible || Math.floor(Date.now() / 100) % 2 === 0) {
        ctx.font = '60px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(selectedAvatar, stateRef.current.playerX, canvas.height - 100);
      }

      // Items
      if (Math.random() < 0.04) spawn();

      for (let i = stateRef.current.items.length - 1; i >= 0; i--) {
        const item = stateRef.current.items[i];
        item.y += item.speed;

        ctx.font = '45px Arial';
        ctx.fillText(item.emoji, item.x, item.y);

        // Collision
        const dx = Math.abs(stateRef.current.playerX - item.x);
        const dy = Math.abs((canvas.height - 100) - item.y);
        
        if (dx < 50 && dy < 50) {
          if (item.type === 'good') {
            stateRef.current.score += 10;
            setScore(stateRef.current.score);
          } else if (!isInvincible) {
            stateRef.current.lives -= 1;
            stateRef.current.lastHit = Date.now();
            setLives(stateRef.current.lives);
            if (stateRef.current.lives <= 0) {
              setGameState('OVER');
              return;
            }
          }
          stateRef.current.items.splice(i, 1);
        } else if (item.y > canvas.height + 50) {
          stateRef.current.items.splice(i, 1);
        }
      }

      frameId = requestAnimationFrame(update);
    };

    update();
    return () => cancelAnimationFrame(frameId);
  }, [gameState, selectedAvatar]);

  const startGame = () => {
    stateRef.current.score = 0;
    stateRef.current.lives = 3;
    stateRef.current.items = [];
    setScore(0);
    setLives(3);
    setGameState('PLAYING');
  };

  return (
    <div className="relative w-full h-full bg-gradient-to-b from-[#a39193] to-[#66545e]">
      <button 
        onClick={onExit}
        className="absolute top-6 left-6 z-50 px-6 py-2 bg-[#aa6f73] text-[#f6e0b5] rounded-full font-bold shadow-lg"
      >
        ← LOBBY
      </button>

      {gameState === 'PLAYING' && (
        <>
          <canvas ref={canvasRef} className="w-full h-full" />
          <div className="absolute top-6 right-6 text-right pointer-events-none">
            <div className="text-4xl font-bold text-[#f6e0b5] drop-shadow-md">Score: {score}</div>
            <div className="text-3xl mt-2">{"❤️".repeat(lives)}</div>
          </div>
        </>
      )}

      {gameState === 'START' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm p-6">
          <h1 className="text-5xl font-bold text-[#f6e0b5] mb-4">Birthday Rush</h1>
          <p className="text-[#eea990] mb-8 text-center max-w-md">Catch the treats, avoid the healthy stuff! Use arrows to move.</p>
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {AVATARS.map(av => (
              <button 
                key={av}
                onClick={() => setSelectedAvatar(av)}
                className={`text-4xl p-3 rounded-full border-4 transition-all ${selectedAvatar === av ? 'border-[#eea990] bg-white/20 scale-125' : 'border-transparent'}`}
              >
                {av}
              </button>
            ))}
          </div>
          <button 
            onClick={startGame}
            className="px-10 py-4 bg-[#aa6f73] text-[#f6e0b5] rounded-full text-2xl font-bold shadow-xl hover:scale-105 active:scale-95"
          >
            LET'S PARTY!
          </button>
        </div>
      )}

      {gameState === 'OVER' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-md p-6">
          <h1 className="text-6xl font-bold text-[#eea990] mb-4">Oh No! ✨</h1>
          <p className="text-[#f6e0b5] text-2xl mb-8">You celebrated hard! Final Score: {score}</p>
          <div className="flex gap-4">
            <button 
              onClick={startGame}
              className="px-8 py-3 bg-[#aa6f73] text-[#f6e0b5] rounded-full text-xl font-bold shadow-xl"
            >
              TRY AGAIN
            </button>
            <button 
              onClick={onExit}
              className="px-8 py-3 bg-zinc-700 text-[#f6e0b5] rounded-full text-xl font-bold shadow-xl"
            >
              QUIT
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default BirthdayRush;
