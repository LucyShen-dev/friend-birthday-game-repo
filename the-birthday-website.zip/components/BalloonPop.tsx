
import React, { useEffect, useRef, useState } from 'react';
import { GameProps } from '../types';

const COLORS = ["#aa6f73", "#eea990", "#f6e0b5", "#a39193", "#66545e"];

const BalloonPop: React.FC<GameProps> = ({ onExit }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'START' | 'PLAYING' | 'OVER'>('START');
  const [score, setScore] = useState(0);
  const [escaped, setEscaped] = useState(0);

  const engineRef = useRef({
    balloons: [] as any[],
    score: 0,
    escaped: 0
  });

  useEffect(() => {
    if (gameState !== 'PLAYING') return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let frameId: number;

    const spawn = () => {
      engineRef.current.balloons.push({
        x: Math.random() * (canvas.width - 100) + 50,
        y: canvas.height + 60,
        r: 40 + Math.random() * 15,
        speed: Math.random() * 1.5 + 1.2 + (engineRef.current.score / 100),
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        wobble: Math.random() * Math.PI * 2
      });
    };

    const handleClick = (e: MouseEvent | TouchEvent) => {
      const rect = canvas.getBoundingClientRect();
      const x = ('touches' in e) ? e.touches[0].clientX : e.clientX;
      const y = ('touches' in e) ? e.touches[0].clientY : e.clientY;
      const mx = x - rect.left;
      const my = y - rect.top;

      for (let i = engineRef.current.balloons.length - 1; i >= 0; i--) {
        const b = engineRef.current.balloons[i];
        const dist = Math.sqrt((mx - b.x) ** 2 + (my - b.y) ** 2);
        if (dist < b.r + 10) {
          engineRef.current.balloons.splice(i, 1);
          engineRef.current.score += 1;
          setScore(engineRef.current.score);
          return;
        }
      }
    };

    canvas.addEventListener('mousedown', handleClick);
    canvas.addEventListener('touchstart', handleClick, { passive: false });

    const update = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (Math.random() < 0.03 + (engineRef.current.score / 1500)) spawn();

      for (let i = engineRef.current.balloons.length - 1; i >= 0; i--) {
        const b = engineRef.current.balloons[i];
        b.y -= b.speed;
        b.wobble += 0.05;
        b.x += Math.sin(b.wobble) * 1.5;

        // Draw Balloon Body
        ctx.fillStyle = b.color;
        ctx.beginPath();
        ctx.ellipse(b.x, b.y, b.r * 0.9, b.r, 0, 0, Math.PI * 2);
        ctx.fill();

        // Reflection
        ctx.fillStyle = "rgba(255,255,255,0.25)";
        ctx.beginPath();
        ctx.arc(b.x - b.r * 0.3, b.y - b.r * 0.4, b.r * 0.2, 0, Math.PI * 2);
        ctx.fill();

        // String
        ctx.strokeStyle = "rgba(246, 224, 181, 0.4)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(b.x, b.y + b.r);
        ctx.bezierCurveTo(b.x - 10, b.y + b.r + 20, b.x + 10, b.y + b.r + 40, b.x, b.y + b.r + 60);
        ctx.stroke();

        if (b.y < -100) {
          engineRef.current.balloons.splice(i, 1);
          engineRef.current.escaped += 1;
          setEscaped(engineRef.current.escaped);
          if (engineRef.current.escaped >= 5) {
            setGameState('OVER');
          }
        }
      }

      frameId = requestAnimationFrame(update);
    };

    update();
    return () => {
      cancelAnimationFrame(frameId);
      canvas.removeEventListener('mousedown', handleClick);
      canvas.removeEventListener('touchstart', handleClick);
    };
  }, [gameState]);

  const startGame = () => {
    engineRef.current.score = 0;
    engineRef.current.escaped = 0;
    engineRef.current.balloons = [];
    setScore(0);
    setEscaped(0);
    setGameState('PLAYING');
  };

  return (
    <div className="relative w-full h-full bg-[#66545e] overflow-hidden">
      <button 
        onClick={onExit}
        className="absolute top-6 left-6 z-50 px-6 py-2 bg-[#aa6f73] text-[#f6e0b5] rounded-full font-bold shadow-lg"
      >
        ← LOBBY
      </button>

      {gameState === 'PLAYING' && (
        <>
          <canvas ref={canvasRef} className="w-full h-full cursor-crosshair" />
          <div className="absolute top-6 right-6 text-right pointer-events-none">
            <div className="text-4xl font-bold text-[#f6e0b5] drop-shadow-md">Pops: {score}</div>
            <div className="text-[#eea990] text-xl mt-1">Missed: {escaped}/5</div>
          </div>
        </>
      )}

      {gameState === 'START' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/10 backdrop-blur-md p-6 text-center">
          <span className="text-8xl mb-6">🎈</span>
          <h1 className="text-5xl font-bold text-[#f6e0b5] mb-4">Balloon Pop</h1>
          <p className="text-[#eea990] mb-12 max-w-sm text-lg font-medium">Relax and pop the floating balloons. Don't let too many float away!</p>
          <button 
            onClick={startGame}
            className="px-12 py-4 bg-[#aa6f73] text-[#f6e0b5] rounded-full text-2xl font-bold shadow-xl hover:bg-[#8b5a5e] transition-colors"
          >
            START POPPING
          </button>
        </div>
      )}

      {gameState === 'OVER' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#66545e]/90 backdrop-blur-xl p-6 text-center">
          <h1 className="text-6xl font-bold text-[#eea990] mb-4">Pop-tastic!</h1>
          <p className="text-[#f6e0b5] text-2xl mb-12">You popped {score} balloons today. ✨</p>
          <div className="flex flex-col gap-4 w-full max-w-xs">
            <button 
              onClick={startGame}
              className="px-8 py-4 bg-[#aa6f73] text-[#f6e0b5] rounded-full text-xl font-bold shadow-xl"
            >
              PLAY AGAIN
            </button>
            <button 
              onClick={onExit}
              className="px-8 py-4 bg-zinc-700 text-[#f6e0b5] rounded-full text-xl font-bold shadow-xl"
            >
              BACK TO LOBBY
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default BalloonPop;
