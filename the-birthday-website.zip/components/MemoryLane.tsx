
import React, { useState, useEffect } from 'react';
import { GameProps } from '../types';

const ICONS = ["🦢", "🌸", "🍰", "🎀", "🕯️", "☁️", "🐚", "🩰"];

const MemoryLane: React.FC<GameProps> = ({ onExit }) => {
  const [cards, setCards] = useState<{ icon: string; flipped: boolean; matched: boolean }[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [showWin, setShowWin] = useState(false);

  useEffect(() => {
    initGame();
  }, []);

  const initGame = () => {
    const deck = [...ICONS, ...ICONS]
      .sort(() => Math.random() - 0.5)
      .map(icon => ({ icon, flipped: false, matched: false }));
    setCards(deck);
    setFlippedIndices([]);
    setMoves(0);
    setShowWin(false);
  };

  const handleFlip = (index: number) => {
    if (flippedIndices.length === 2 || cards[index].flipped || cards[index].matched) return;

    const newCards = [...cards];
    newCards[index].flipped = true;
    setCards(newCards);

    const newFlipped = [...flippedIndices, index];
    setFlippedIndices(newFlipped);

    if (newFlipped.length === 2) {
      setMoves(m => m + 1);
      const [first, second] = newFlipped;
      if (cards[first].icon === cards[second].icon) {
        // Match
        setTimeout(() => {
          const matchCards = [...cards];
          matchCards[first].matched = true;
          matchCards[second].matched = true;
          setCards(matchCards);
          setFlippedIndices([]);
          if (matchCards.every(c => c.matched)) {
            setTimeout(() => setShowWin(true), 500);
          }
        }, 600);
      } else {
        // No match
        setTimeout(() => {
          const resetCards = [...cards];
          resetCards[first].flipped = false;
          resetCards[second].flipped = false;
          setCards(resetCards);
          setFlippedIndices([]);
        }, 1000);
      }
    }
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-[#a39193] via-[#66545e] to-[#aa6f73] flex flex-col items-center pt-24 px-4 overflow-y-auto pb-10">
      <button 
        onClick={onExit}
        className="fixed top-6 left-6 z-50 px-6 py-2 bg-[#aa6f73] text-[#f6e0b5] rounded-full font-bold shadow-lg"
      >
        ← LOBBY
      </button>

      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-[#f6e0b5] tracking-widest drop-shadow-md">MEMORY LANE</h1>
        <p className="text-[#eea990] mt-2">Find all pairs in {moves} moves</p>
      </div>

      <div className="grid grid-cols-4 gap-3 max-w-md w-full aspect-square perspective-1000">
        {cards.map((card, idx) => (
          <div 
            key={idx}
            onClick={() => handleFlip(idx)}
            className={`relative w-full h-full cursor-pointer transition-transform duration-500 transform-style-preserve-3d ${card.flipped || card.matched ? 'rotate-y-180' : ''}`}
          >
            {/* Front of card (Icon side) */}
            <div className="absolute inset-0 backface-hidden rotate-y-180 bg-[#f6e0b5] rounded-xl flex items-center justify-center text-4xl shadow-xl border-4 border-white/20">
              {card.icon}
            </div>
            {/* Back of card (Decorative side) */}
            <div className="absolute inset-0 backface-hidden bg-[#aa6f73] rounded-xl flex items-center justify-center text-3xl shadow-lg border-2 border-[#eea990]/40 text-white/40">
              ✨
            </div>
            {card.matched && (
              <div className="absolute -top-1 -right-1 z-10 text-xl">✨</div>
            )}
          </div>
        ))}
      </div>

      {showWin && (
        <div className="fixed inset-0 z-[60] flex flex-col items-center justify-center bg-black/70 backdrop-blur-md p-6 text-center">
          <div className="bg-[#66545e] p-12 rounded-[3rem] border-4 border-[#eea990] shadow-2xl animate-float">
            <h1 className="text-5xl font-bold text-[#f6e0b5] mb-4">Lovely Memory!</h1>
            <p className="text-[#eea990] text-xl mb-10">You matched everything in {moves} moves. ✨</p>
            <div className="flex gap-4">
              <button 
                onClick={initGame}
                className="px-8 py-3 bg-[#aa6f73] text-[#f6e0b5] rounded-full font-bold shadow-lg hover:bg-[#8b5a5e] transition-colors"
              >
                PLAY AGAIN
              </button>
              <button 
                onClick={onExit}
                className="px-8 py-3 bg-zinc-700 text-[#f6e0b5] rounded-full font-bold shadow-lg"
              >
                FINISH
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MemoryLane;
