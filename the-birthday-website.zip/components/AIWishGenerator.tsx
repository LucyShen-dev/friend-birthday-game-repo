
import React, { useState } from 'react';
import { GameProps } from '../types';
import { generateBirthdayWish } from '../services/geminiService';

const AIWishGenerator: React.FC<GameProps> = ({ onExit }) => {
  const [name, setName] = useState('');
  const [vibes, setVibes] = useState('');
  const [wish, setWish] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setIsLoading(true);
    const result = await generateBirthdayWish(name, vibes || "cozy, soft, dreamy");
    setWish(result);
    setIsLoading(false);
  };

  return (
    <div className="w-full h-full bg-[#a39193] flex flex-col items-center justify-center p-6 text-center overflow-y-auto scrollbar-hide">
      <button 
        onClick={onExit}
        className="fixed top-6 left-6 z-50 px-6 py-2 bg-[#aa6f73] text-[#f6e0b5] rounded-full font-bold shadow-lg"
      >
        ← LOBBY
      </button>

      <div className="w-full max-w-lg bg-[#66545e] p-8 rounded-[3rem] shadow-2xl border-4 border-[#f6e0b5]/20 animate-float">
        {!wish ? (
          <>
            <h1 className="text-4xl font-bold text-[#f6e0b5] mb-4 drop-shadow-md">GEMINI WISH ✨</h1>
            <p className="text-[#eea990] mb-8 font-medium">Let Gemini weave a poetic birthday blessing just for you.</p>
            
            <form onSubmit={handleGenerate} className="space-y-6">
              <div className="text-left">
                <label className="block text-[#f6e0b5] ml-4 mb-2 font-bold text-sm uppercase tracking-widest">Your Name</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Tell Gemini who you are..."
                  className="w-full px-6 py-4 bg-black/20 border-2 border-[#eea990]/30 rounded-full text-[#f6e0b5] focus:outline-none focus:border-[#eea990] transition-colors"
                />
              </div>

              <div className="text-left">
                <label className="block text-[#f6e0b5] ml-4 mb-2 font-bold text-sm uppercase tracking-widest">Desired Vibes</label>
                <input 
                  type="text" 
                  value={vibes}
                  onChange={(e) => setVibes(e.target.value)}
                  placeholder="e.g. cottagecore, synthwave, soft..."
                  className="w-full px-6 py-4 bg-black/20 border-2 border-[#eea990]/30 rounded-full text-[#f6e0b5] focus:outline-none focus:border-[#eea990] transition-colors"
                />
              </div>

              <button 
                disabled={isLoading || !name}
                className="w-full py-5 bg-[#aa6f73] text-[#f6e0b5] rounded-full text-xl font-bold shadow-xl hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
              >
                {isLoading ? "Consulting the Stars..." : "GENERATE BLESSING ✨"}
              </button>
            </form>
          </>
        ) : (
          <div className="flex flex-col items-center">
            <h2 className="text-2xl font-bold text-[#eea990] mb-8 tracking-widest uppercase">A BLESSING FOR {name}</h2>
            <p className="text-[#f6e0b5] text-2xl leading-relaxed italic font-medium whitespace-pre-wrap mb-10">
              "{wish}"
            </p>
            <div className="flex gap-4">
              <button 
                onClick={() => setWish(null)}
                className="px-8 py-3 bg-[#aa6f73] text-[#f6e0b5] rounded-full font-bold shadow-lg"
              >
                ANOTHER ONE?
              </button>
              <button 
                onClick={onExit}
                className="px-8 py-3 bg-zinc-700 text-[#f6e0b5] rounded-full font-bold shadow-lg"
              >
                DONE
              </button>
            </div>
          </div>
        )}
      </div>
      
      {/* Visual Accents */}
      <div className="mt-12 text-[#f6e0b5]/40 text-sm font-medium tracking-widest uppercase flex gap-4">
        <span>🕯️</span>
        <span>AESTHETIC</span>
        <span>☁️</span>
        <span>ETHEREAL</span>
        <span>🌸</span>
      </div>
    </div>
  );
};

export default AIWishGenerator;
