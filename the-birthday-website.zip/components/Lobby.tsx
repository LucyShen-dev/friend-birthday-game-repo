
import React from 'react';
import { GameType } from '../types';

interface LobbyProps {
  onSelectGame: (game: GameType) => void;
  onToggleMusic: () => void;
  isPlaying: boolean;
}

const Lobby: React.FC<LobbyProps> = ({ onSelectGame, onToggleMusic, isPlaying }) => {
  const games = [
    { id: GameType.RUSH, icon: '🍓', title: 'Birthday Rush', desc: 'A playful treat-catching activity.' },
    { id: GameType.BALLOON, icon: '☁️', title: 'Balloon Pop', desc: 'A serene interactive landscape.' },
    { id: GameType.MEMORY, icon: '🕯️', title: 'Memory Lane', desc: 'A classic game of pairs and nostalgia.' },
    { id: GameType.AI_WISH, icon: '✨', title: 'Gemini Blessing', desc: 'An AI-crafted poetic greeting.' },
  ];

  return (
    <div className="w-full h-full flex flex-col items-center pt-10 px-6 overflow-y-auto pb-32 scrollbar-hide">
      {/* Hero Section */}
      <section className="text-center mb-10 animate-float">
        <h1 className="text-5xl md:text-7xl font-bold text-[#f6e0b5] tracking-tighter drop-shadow-2xl">
          THE BIRTHDAY<br/>COLLECTION
        </h1>
        <div className="w-16 h-1 bg-[#eea990] mx-auto my-6 opacity-60"></div>
        <p className="text-[#eea990] text-lg md:text-xl font-light italic max-w-lg mx-auto opacity-90 px-4">
          "A sanctuary of digital delights, curated for your special day."
        </p>
      </section>

      {/* Featured Music Interaction - Slightly smaller to bring buttons up */}
      <div className="mb-12 flex flex-col items-center">
        <div className="relative group">
          <div 
            onClick={onToggleMusic}
            className={`w-36 h-36 md:w-44 md:h-44 bg-zinc-900 rounded-full border-4 md:border-8 border-[#eea990] shadow-2xl flex items-center justify-center cursor-pointer transition-all duration-700 ${isPlaying ? 'animate-spin-slow scale-105 shadow-[0_0_50px_rgba(238,169,144,0.3)]' : 'scale-100 opacity-80'}`}
          >
            <div className="w-16 h-16 md:w-20 md:h-20 bg-[#aa6f73] rounded-full border-4 md:border-8 border-zinc-800 flex items-center justify-center text-[8px] md:text-[10px] text-[#f6e0b5] font-black text-center leading-none">
              BDAY<br/>HITS
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 md:w-2 h-1 md:h-2 bg-zinc-800 rounded-full"></div>
          </div>
          {/* Tone Arm */}
          <div className={`absolute -top-2 -right-10 w-20 md:w-24 h-3 md:h-4 bg-zinc-700 origin-left transition-transform duration-500 rounded-full shadow-lg ${isPlaying ? 'rotate-[35deg]' : 'rotate-[10deg]'}`}></div>
        </div>
        <button 
          onClick={onToggleMusic}
          className="mt-6 px-6 py-2 bg-[#aa6f73] text-[#f6e0b5] rounded-full font-bold shadow-xl hover:bg-[#8b5a5e] transition-all tracking-widest uppercase text-[10px]"
        >
          {isPlaying ? 'Pause Vibes ⏸' : 'Play Vibes ▶'}
        </button>
      </div>

      {/* Grid Section - Stronger backgrounds for better visibility */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 w-full max-w-6xl">
        {games.map((game) => (
          <button
            key={game.id}
            onClick={() => onSelectGame(game.id)}
            className="flex flex-col items-center p-8 bg-[#aa6f73]/15 backdrop-blur-xl border border-white/20 rounded-[2.5rem] hover:bg-[#aa6f73]/30 hover:-translate-y-2 transition-all duration-300 group shadow-lg active:scale-95"
          >
            <span className="text-6xl mb-4 group-hover:scale-110 transition-transform duration-300">{game.icon}</span>
            <h2 className="text-xl font-bold text-[#f6e0b5] tracking-wide">{game.title}</h2>
            <div className="w-6 h-[2px] bg-[#eea990] my-3 group-hover:w-12 transition-all"></div>
            <p className="text-[#f6e0b5]/80 text-sm font-medium leading-relaxed px-2">{game.desc}</p>
          </button>
        ))}
      </div>

      {/* Website Flourish */}
      <div className="mt-20 text-center text-[#f6e0b5]/30 text-[10px] font-bold tracking-[0.4em] uppercase">
        Explore & Celebrate
      </div>
    </div>
  );
};

export default Lobby;
